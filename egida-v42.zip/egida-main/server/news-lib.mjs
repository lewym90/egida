// EGIDA – logika „Ważne w regionie”: parsery RSS i list gov.pl, filtr słów kluczowych, deduplikacja. Czysta, bez sieci (testy: scripts/test-v17.mjs).
// Zasada: tylko oficjalne, zaufane źródła (Policja, MEN, RCB, urzędy wojewódzkie, kuratoria). Nic nie piszemy od siebie, nic nie omijamy.
import { XMLParser } from "fast-xml-parser";
import { dedupeSimilar } from "../js/similar.js";
import { resolvePlace, nationalScope, topicHit, isWorldPath, topTarget } from "./news-geo.mjs";
import { mentionsRegion, nationalCore, nationalThreat, regionsMentioned, strongIncident, foreignEvent, polishHint } from "./news-places.mjs";

export const LIMITS = { perSource: 15, total: 200, maxAgeDays: 14, titleChars: 200, summaryChars: 280 };

// Słowa kluczowe bezpieczeństwa (rdzenie, bez polskich znaków diakrytycznych po normalizacji).
const SAFETY = [
  "alarm bombow", "grozb", "pogrozk", "zagroz", "ostrzez", "ostrzeg", "ewakuac", "zamach", "atak", "strzelani", "nozown", "niebezpiecz",
  "falszyw", "dezinformac", "fejk", "nieprawdziw", "oszust", "wyludz", "podszyw", "komunikat", "apel ", "apelu", "apeluj", "bezpieczen", "ludnosci", "obron cywiln",
  "schron", "dron", "rakiet", "wybuch", "pozar", "powodz", "wichur", "burz", "nawalnic", "upal", "gololed", "smog", "skazeni", "awari", "brak pradu",
  "cyberatak", "cyberbezp", "przemoc", "agresj", "amunicj", "materialy wybuchow", "arsenal",
  "kryzysow", "bezpieczn", "wypadk", "karambol", "tragiczn", "zgin", "nie zyj", "zabojstw", "napad", "porwan", "zaginion",
];
// Dla szkół i kuratoriów: tylko wpisy o bezpieczeństwie (bez planów lekcji, konkursów itp.).
const SCHOOL_SAFETY = ["bezpiecz", "zagroz", "grozb", "alarm", "ewakuac", "przemoc", "atak", "komunikat", "apel ", "apelu", "apeluj", "ostrzez", "cyber", "policj", "ochron", "dezinformac", "falszyw", "wstrzyman", "zawiesz"];

// Źródła oficjalne (filtr „safety” i „school”): wpisy o inwestycjach, szkoleniach, nagrodach itp. nie są komunikatami o bezpieczeństwie.
const OFFICIAL_DENY_HARD = ["remont", "uroczyst", "studi", "podyplom", "wyroznien", "briefing", "zapowiedz", "nabor", "ubezpiecze", "targ", "poleco", "szczepie", "nagrod", "jubileusz", "konkurs", "absolwent", "stypendi", "dziecinstwo bez przemocy", "wspieramy dziecinstwo", "kosmiczn", "energetycz"];
const OFFICIAL_DENY_SOFT = ["technologi", "wspolprac", "inwestycj", "mln zl", "mld zl", "konferencj", "armii"];
const CIVIL = ["ochron ludnosci", "ochrony ludnosci", "ochrone ludnosci", "obron cywiln", "obrone cywiln", "schron", "alarm", "ostrzez", "ewakuac", "komunikat"];
// Filtr „civil” (MON, MSWiA): tylko ochrona ludności i bezpośrednie zagrożenia, bez ogólnych wpisów o „bezpieczeństwie” (rozmowy, wizyty).
const CIVIL_STRICT = ["ochron ludnosci", "ochrony ludnosci", "ochrone ludnosci", "obron cywiln", "obrone cywiln", "schron", "alarm", "ostrzez", "ostrzeg", "ewakuac", "komunikat", "dron", "rakiet", "przestrzen powietrzn", "przestrzeni powietrzn", "sabota", "cyberatak", "zagrozeni", "powodz", "pozar", "skazeni"];
const fold = (s) => String(s || "").toLowerCase().replace(/ł/g, "l").normalize("NFD").replace(/[̀-ͯ]/g, "");
const matches = (text, words) => { const t = fold(text); return words.some((w) => new RegExp("(^|[^a-z0-9])" + fold(w)).test(t)); }; // dopasowanie od początku wyrazu

/** Filtr: "all" (bez filtra), "safety" (słowa bezpieczeństwa), "school" (węższy zestaw dla MEN/kuratoriów), "civil" (MON/MSWiA: ochrona ludności i bezpośrednie zagrożenia). */
export function passesFilter(mode, title, summary = "") {
  if (mode === "all") return true;
  if (mode === "media") return passesMedia(title); // tylko tytuł
  const text = `${title} ${summary}`;
  if (matches(title, OFFICIAL_DENY_HARD)) return false;
  if (matches(title, OFFICIAL_DENY_SOFT) && !matches(title, CIVIL)) return false;
  if (mode === "school") return matches(text, SCHOOL_SAFETY);
  if (mode === "civil") return matches(text, CIVIL_STRICT);
  return matches(text, SAFETY);
}

const NAMED = { nbsp: " ", amp: "&", quot: '"', apos: "'", lt: "<", gt: ">", ndash: "–", mdash: "—", hellip: "…", bdquo: "„", ldquo: "“", rdquo: "”", laquo: "«", raquo: "»", lsquo: "‘", rsquo: "’", sbquo: "‚", oacute: "ó", Oacute: "Ó", aogon: "ą", Aogon: "Ą", eogon: "ę", Eogon: "Ę", cacute: "ć", Cacute: "Ć", sacute: "ś", Sacute: "Ś", zacute: "ź", Zacute: "Ź", zdot: "ż", Zdot: "Ż", nacute: "ń", Nacute: "Ń", lstrok: "ł", Lstrok: "Ł", eacute: "é", uuml: "ü", ouml: "ö", auml: "ä", copy: "©", deg: "°", euro: "€", bull: "•", middot: "·", shy: "" };
/** Zamienia encje HTML (nazwane i liczbowe) na znaki; powtarza raz, bo część kanałów koduje podwójnie („&amp;ndash;”). */
export const decodeEntities = (s) => { let t = String(s || ""); for (let i = 0; i < 2; i++) t = t.replace(/&(?:#(\d{1,6})|#[xX]([0-9a-fA-F]{1,6})|([A-Za-z][A-Za-z0-9]{1,8}));/g, (m, d, h, n) => { try { if (d) return String.fromCodePoint(Number(d)); if (h) return String.fromCodePoint(parseInt(h, 16)); return n in NAMED ? NAMED[n] : m; } catch { return m; } }); return t; };
const stripTags = (s) => decodeEntities(String(s || "").replace(/<[^>]*>/g, " ")).replace(/\s+/g, " ").trim();
const clip = (s, n) => (s.length > n ? s.slice(0, n - 1).trimEnd() + "…" : s);
const toIso = (v) => { const d = new Date(v); return Number.isFinite(d.getTime()) ? d.toISOString() : null; };
/** Tylko adresy https (nigdy javascript:, data:). */
export function safeHttps(u) { try { const x = new URL(u); return x.protocol === "https:" ? x.href : null; } catch { return null; } }

/** RSS 2.0 / Atom → [{title, url, date, summary}] */
export function parseRss(xml) {
  const p = new XMLParser({ ignoreAttributes: false, attributeNamePrefix: "@_", processEntities: true, trimValues: true });
  let j; try { j = p.parse(String(xml)); } catch { return []; }
  const arr = (x) => (x == null ? [] : Array.isArray(x) ? x : [x]);
  const txt = (v) => (v && typeof v === "object" ? v["#text"] ?? "" : v ?? "");
  const out = [];
  const base = safeHttps(stripTags(txt(j?.rss?.channel?.link))); // niektóre kanały (np. Radio Opole) podają adresy względne
  const abs = (l) => { const x = stripTags(txt(l)); if (!x) return null; try { return safeHttps(new URL(x, base || undefined).href); } catch { return null; } };
  for (const it of arr(j?.rss?.channel?.item)) {
    const title = stripTags(txt(it.title)), url = abs(it.link);
    if (!title || !url) continue;
    out.push({ title, url, date: toIso(txt(it.pubDate) || txt(it.date) || txt(it["dc:date"])), summary: stripTags(txt(it.description)), catList: arr(it.category).map((c) => stripTags(txt(c))).filter(Boolean), cats: arr(it.category).map((c) => stripTags(txt(c))).join(" ") });
  }
  for (const it of arr(j?.["rdf:RDF"]?.item)) { // RSS 1.0 (RDF), np. Radio Szczecin
    const title = stripTags(txt(it.title)), url = safeHttps(stripTags(txt(it.link)));
    if (!title || !url) continue;
    out.push({ title, url, date: toIso(txt(it["dc:date"]) || txt(it.pubDate)), summary: stripTags(txt(it.description)), cats: "" });
  }
  for (const it of arr(j?.feed?.entry)) {
    const l = arr(it.link).find((x) => x?.["@_rel"] !== "self") || arr(it.link)[0];
    const title = stripTags(txt(it.title)), url = safeHttps(l?.["@_href"] || "");
    if (!title || !url) continue;
    out.push({ title, url, date: toIso(txt(it.updated) || txt(it.published)), summary: stripTags(txt(it.summary)) });
  }
  return out;
}

/** Adresy kanałów RSS Policji znalezione na stronie głównej/stronie RSS: /dokumenty/rss/<id>-rss-o-<id>.rss (różne dla każdej jednostki). */
export function discoverFeeds(html, baseUrl) {
  const found = new Set();
  for (const m of String(html).matchAll(/(?:href|src)\s*=\s*["']([^"']*\/dokumenty\/rss\/[^"']+?\.rss)["']/gi)) {
    try { found.add(new URL(m[1].replace(/&amp;/g, "&"), baseUrl).href); } catch { /* pomiń */ }
  }
  for (const m of String(html).matchAll(/<link[^>]+type=["']application\/(?:rss|atom)\+xml["'][^>]*>/gi)) {
    const h = /href=["']([^"']+)["']/i.exec(m[0]); if (h) try { found.add(new URL(h[1], baseUrl).href); } catch { /* pomiń */ }
  }
  const list = [...found];
  // Kanał „Aktualności” ma w nazwie „rss-o-” – bierzemy go przed pozostałymi.
  list.sort((a, b) => Number(/rss-o-/.test(b)) - Number(/rss-o-/.test(a)));
  return list;
}

/** Strony „Kanały RSS” jednostki Policji (np. /ra/rss, /opo/rss): link z głównej strony albo odgadnięty z innych linków /<skrót>/sitemap, /<skrót>/wai. */
export function discoverRssPages(html, baseUrl) {
  const out = new Set(), src = String(html);
  for (const m of src.matchAll(/href\s*=\s*["']([^"']*\/[a-z0-9]{2,6}\/rss\/?)["']/gi)) { try { out.add(new URL(m[1], baseUrl).href); } catch { /* pomiń */ } }
  if (!out.size) for (const m of src.matchAll(/href\s*=\s*["'][^"']*?\/([a-z0-9]{2,6})\/(?:sitemap|wai|kontakt)\/?["']/gi)) { try { out.add(new URL(`/${m[1]}/rss`, baseUrl).href); } catch { /* pomiń */ } break; }
  return [...out].slice(0, 2);
}

const DATE_RE = /\b(\d{2})\.(\d{2})\.(\d{4})\b|\b(\d{4})-(\d{2})-(\d{2})\b/;
const dateFrom = (s) => { const m = DATE_RE.exec(s); if (!m) return null; const [y, mo, d] = m[1] ? [m[3], m[2], m[1]] : [m[4], m[5], m[6]]; return toIso(`${y}-${mo}-${d}T12:00:00+02:00`); };

/**
 * Lista aktualności ze strony HTML (gov.pl i podobne): link o treści ≥ 25 znaków + najbliższa data DD.MM.YYYY (lub RRRR-MM-DD) w pobliżu.
 * Zwraca [{title, url, date}]; wpisy bez daty pomijamy (nie wiemy, czy są świeże).
 */
export function parseHtmlList(html, baseUrl) {
  const out = [], seen = new Set(), src = String(html);
  for (const m of src.matchAll(/<a\b[^>]*href\s*=\s*["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi)) {
    // Karta „cały wpis w jednym linku” (Policja): tytuł bierzemy z nagłówka/elementu o klasie tytułu, a przy braku – pierwsze 160 znaków.
    const hd = /<h[1-6][^>]*>([\s\S]*?)<\/h[1-6]>/i.exec(m[2]) || /<(?:span|div|p|strong|b)[^>]*class\s*=\s*["'][^"']*(?:tytu|title|naglow|headline)[^"']*["'][^>]*>([\s\S]*?)<\/(?:span|div|p|strong|b)>/i.exec(m[2]);
    let title = stripTags(hd ? hd[1] : m[2]);
    if (title.length > 400) title = clip(title.replace(DATE_RE, "").replace(/\s+/g, " ").trim(), 160);
    if (title.length < 25) continue;
    let url; try { url = safeHttps(new URL(m[1].replace(/&amp;/g, "&"), baseUrl).href); } catch { continue; }
    if (!url || seen.has(url)) continue;
    // Data: w treści linku, potem tuż przed nim (nagłówek karty), na końcu tuż po nim.
    const idx = m.index;
    // Okno „przed” kończy się na poprzednim linku/elemencie listy, okno „po” na następnym wpisie (link do artykułu /NNNN,Tytul.html lub <li>), żeby nie pożyczyć daty od sąsiada.
    let before = src.slice(Math.max(0, idx - 350), idx), after = src.slice(idx + m[0].length, idx + m[0].length + 700);
    before = before.slice(Math.max(before.lastIndexOf("</a>") + 4, before.lastIndexOf("</li>") + 5, before.lastIndexOf("</p>") + 4, before.lastIndexOf("<li") >= 0 ? before.lastIndexOf("<li") : 0, 0));
    const cut = after.search(/<li\b|href\s*=\s*["'][^"']*\/\d{4,},/i); if (cut >= 0) after = after.slice(0, cut);
    const date = dateFrom((/datetime\s*=\s*["']([^"']+)["']/i.exec(m[2]) || [])[1] || "") || dateFrom(stripTags(m[2])) || dateFrom(stripTags(before).slice(-60)) || dateFrom(stripTags(after).slice(0, 400));
    if (!date) continue;
    seen.add(url); out.push({ title: title.replace(DATE_RE, "").replace(/\s+/g, " ").trim() || title, url, date, summary: "" });
  }
  return out;
}

/**
 * Rozgłośnie bez kanału RSS: czytamy listę wiadomości ze strony. Bierzemy tylko linki pasujące do wzorca artykułów rozgłośni (rule.link),
 * tytuł z nagłówka, atrybutu title albo najdłuższego fragmentu tekstu w linku. Daty na stronie bywają niejednoznaczne (np. „godzinę temu”),
 * więc datę ustala wywołujący (pierwsze zobaczenie wpisu przez serwer).
 */
export function parseMediaHtml(html, baseUrl, rule) {
  const re = new RegExp(rule.link), deny = rule.deny ? new RegExp(rule.deny, "i") : null, best = new Map();
  for (const m of String(html).matchAll(/<a\b([^>]*)>([\s\S]*?)<\/a>/gi)) {
    const hm = /href\s*=\s*["']([^"']+)["']/i.exec(m[1]); if (!hm) continue;
    let url; try { url = safeHttps(new URL(hm[1].replace(/&amp;/g, "&"), baseUrl).href); } catch { continue; }
    if (!url) continue; url = url.replace(/#.*$/, "");
    if (!re.test(url) || (deny && deny.test(url))) continue;
    const hd = /<h[1-6][^>]*>([\s\S]*?)<\/h[1-6]>/i.exec(m[2]);
    const tt = /\btitle\s*=\s*["']([^"']+)["']/i.exec(m[1]);
    const segs = m[2].split(/<[^>]+>/).map((x) => stripTags(x)).filter((x) => x.length >= 20);
    const cands = [hd ? stripTags(hd[1]) : "", tt ? stripTags(tt[1]) : "", segs.sort((a, b) => b.length - a.length)[0] || ""].filter((x) => x.length >= 20 && x.length <= 240);
    const t = cands[0];
    if (!t) continue;
    if (!best.has(url) || (best.get(url).length < t.length && !hd)) best.set(url, t);
  }
  return [...best].map(([url, title]) => ({ title: clip(title.replace(/\s+/g, " ").trim(), LIMITS.titleChars), url, summary: "" }));
}

/** Normalizacja wpisu źródłowego do formatu news.json. */
export function toItem(raw, src, nowMs, why = null, info = null) {
  const no = (r) => { why?.push({ title: String(raw.title || "").slice(0, 110), why: r }); return null; };
  if (!raw.date) return no("brak daty");
  const t = new Date(raw.date).getTime(), active = raw.until && new Date(raw.until).getTime() >= nowMs;
  if (!Number.isFinite(t) || t > nowMs + 36e5 || (!active && nowMs - t > LIMITS.maxAgeDays * 864e5)) return no("data"); // za stare albo z przyszłości
  if (!passesFilter(src.filter, raw.title, raw.summary)) return no("filtr słów");
  // Media: wpis musi dotyczyć województwa rozgłośni (tytuł lub kategorie wskazują miejscowość/region), inaczej to wiadomość z kraju lub ze świata.
  // Wyjątek: poważne zagrożenie bezpieczeństwa w Polsce (zamach, planowany atak) – pokazujemy je w województwie, które wymieniono w tekście, a gdy miejsca nie ma, w całym kraju.
  let region = raw.region || src.region;
  if (src.kind === "media") {
    const txt = `${raw.title} ${raw.cats || ""}`, regs = regionsMentioned(raw.title), regsAll = regionsMentioned(txt);
    const pl = resolvePlace(raw); // nowe, ścisłe ustalanie miejsca (odmiany, kategorie, adres, opis, treść artykułu); konflikt = wstrzymanie
    const note = (group, layer) => info?.push({ title: String(raw.title).slice(0, 110), group, layer, source: src.label });
    if (src.national) { // portal ogólnopolski: 1) miejsce z kategorii/adresu/tytułu/opisu/artykułu → województwo; 2) bez miejsca: z kraju / ze świata (ścisła reguła) / nieprzypisane (tylko w aplikacji); inaczej odrzucamy
      const lead = `${raw.title} ${raw.summary || ""} ${(raw.page?.text || "").slice(0, 600)}`;
      if (topTarget(raw.title) && !foreignEvent(raw.title) && !isWorldPath(raw.url)) { region = "all"; note("kraj", "zamach na władze"); }
      else if (pl.status === "ok") { region = pl.region; note(region, pl.layer); }
      else {
        // „Z kraju” tylko z dowodem na Polskę (słowo Polska/polski w tekście, dział /polska/ albo źródło wyłącznie polskie); dawne „nie wiadomo gdzie, więc pewnie u nas” wycięte (zamach na Grenlandii nie jest sprawą Polski).
        const sc = nationalScope(lead, raw.url), legacyAll = nationalThreat(raw.title) && (src.polishOnly || /\/polska(\/|$)/.test(raw.url)) && !isWorldPath(raw.url) && !foreignEvent(raw.title); // zatrzymany Ukrainiec planujący zamach = sprawa Polski
        const scope = sc === "all" || legacyAll ? "all" : sc;
        if (scope === "all") { region = "all"; note("kraj", "temat+Polska"); }
        else if (scope === "world") { region = "world"; note("swiat", "temat+powiązanie"); }
        // Gdy miejsca nie udało się ustalić pewnie (brak albo konflikt dwóch województw), wpis NIE jest pokazywany (decyzja: lepiej pominąć niż pomylić).
        else return no(pl.status === "conflict" ? "konflikt miejsc" : strongIncident(raw.title) ? "brak pewnego miejsca" : "brak miejsca");
      }
    } else if (src.local) { // regionalny portal prywatny (np. Lublin112): domyślnie jego województwo, ale nie wiadomości „z kraju”
      if (nationalThreat(raw.title) && !regs.includes(src.region)) region = regs[0] || (pl.status === "ok" ? pl.region : "all");
      else if (regs.length && !regs.includes(src.region)) region = regs[0];
      else if (!regs.includes(src.region) && pl.status === "ok" && pl.region !== src.region) region = pl.region;
      else if (!regs.includes(src.region) && /(^|[\s,])(kraj|świat|swiat|polityka)([\s,]|$)/i.test(raw.cats || "") && !regsAll.includes(src.region)) return no("z kraju/świata");
    } else if (!mentionsRegion(txt, src.region) && !(pl.status === "ok" && pl.region === src.region)) {
      if (!nationalThreat(txt)) return no("inny region");
      // Rozgłośnia regionalna nigdy nie „wypycha” wiadomości do całego kraju: jeśli tytuł nie wskazuje innego województwa, zostaje w swoim.
      region = regionsMentioned(txt)[0] || (pl.status === "ok" ? pl.region : nationalCore(txt) ? "all" : src.region);
    }
  }
  // Portal policja.pl zbiera wpisy ze wszystkich regionów (region źródła „mixed”): miejsce z kategorii/adresu/tytułu/opisu albo wpis odpada.
  if (src.region === "mixed" && src.kind !== "media") {
    const pl = resolvePlace(raw);
    if (pl.status !== "ok") return no(pl.status === "conflict" ? "konflikt miejsc" : "brak pewnego miejsca");
    region = pl.region;
  }
  const id = raw.key ? `gddkia/${raw.key}` : raw.url.replace(/^https:\/\/(www\.)?/, "").replace(/[?#].*$/, "");
  return { id, title: clip(decodeEntities(raw.title), LIMITS.titleChars), summary: src.kind === "media" ? "" : clip(raw.summary || "", LIMITS.summaryChars), url: raw.url, date: new Date(t).toISOString(), source: src.label, region, kind: src.kind, ...(active ? { until: raw.until } : {}) };
}

/** Łączy wpisy ze wszystkich źródeł: deduplikacja po adresie, limit na źródło, sortowanie od najnowszych. */
const rank = (it) => (it.kind === "media" ? 2 : it.region === "mixed" ? 1 : 0);
const titleKey = (t) => String(t).toLowerCase().replace(/ł/g, "l").normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, " ").trim().slice(0, 80);
/** Łączy wpisy ze wszystkich źródeł: deduplikacja po adresie i po tytule (ta sama wiadomość z portalu krajowego i z komendy; zostaje wersja z komendy), limit na źródło, sortowanie od najnowszych. */
export function mergeItems(lists, nowMs) {
  const byId = new Map();
  for (const items of lists) {
    const sorted = [...items].sort((a, b) => b.date.localeCompare(a.date)), per = items.noCap ? sorted : sorted.slice(0, LIMITS.perSource);
    for (const it of per) if (!byId.has(it.id)) byId.set(it.id, it);
  }
  const byTitle = new Map();
  for (const it of byId.values()) {
    const k = titleKey(it.title), cur = byTitle.get(k);
    if (!cur || rank(it) < rank(cur)) byTitle.set(k, it); // przy tej samej wiadomości wygrywa źródło oficjalne z regionu
  }
  const pref = [...byTitle.values()].sort((a, b) => rank(a) - rank(b) || b.date.localeCompare(a.date)); // ta sama sprawa innymi słowami: zostaje źródło oficjalne, potem nowsze
  const keepIds = new Set(); // podobne tytuły porównujemy w obrębie jednego regionu (ta sama sprawa w dwóch województwach to dwa różne wpisy)
  for (const reg of new Set(pref.map((x) => x.region))) for (const x of dedupeSimilar(pref.filter((y) => y.region === reg && y.kind !== "gddkia"), (y) => y.title, { share: 0.75, minTokens: 4 })) keepIds.add(x.id);
  return pref.filter((x) => x.kind === "gddkia" || keepIds.has(x.id)).filter((x) => nowMs - new Date(x.date).getTime() <= LIMITS.maxAgeDays * 864e5 || (x.until && new Date(x.until).getTime() >= nowMs)).sort((a, b) => b.date.localeCompare(a.date)).slice(0, LIMITS.total);
}

// ---------- GDDKiA: oficjalny plik XML z utrudnieniami na drogach krajowych ----------
const RAW_FOLD = (x) => String(x || "").toLowerCase().replace(/ł/g, "l").normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim();
/** Czas z XML bez strefy traktujemy jako czas polski (CET/CEST). */
export function warsawToMs(str) {
  const m = /^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})(?::(\d{2}))?(Z|[+-]\d{2}:?\d{2})?$/.exec(String(str || "").trim());
  if (!m) { const t = Date.parse(str); return Number.isFinite(t) ? t : null; }
  const [, y, mo, d, h, mi, se = "0", z] = m;
  if (z) return Date.parse(`${y}-${mo}-${d}T${h}:${mi}:${se.padStart(2, "0")}${z === "Z" ? "Z" : z.length === 5 ? z.slice(0, 3) + ":" + z.slice(3) : z}`);
  const asUtc = Date.UTC(+y, +mo - 1, +d, +h, +mi, +se);
  for (const off of [2, 1]) { // CEST (+2) albo CET (+1): wybieramy ten, który po przeliczeniu daje tę samą godzinę w Warszawie
    const t = asUtc - off * 36e5, hh = Number(new Intl.DateTimeFormat("en-GB", { timeZone: "Europe/Warsaw", hour: "2-digit", hour12: false }).format(t));
    if (hh % 24 === Number(h) % 24) return t;
  }
  return asUtc - 36e5;
}
const bool = (v) => v === true || /^(true|1|tak)$/i.test(String(v ?? "").trim());
const oneLine = (v) => stripTags(typeof v === "object" && v ? v["#text"] ?? "" : v ?? "");
export const GDDKIA_LINK = "https://drogi.gddkia.gov.pl/informacje-drogowe/lista-utrudnien";

/**
 * utrdane.xml → wpisy [{title, url, date, summary, region, until}]. Pokazujemy tylko to, co poważnie wpływa na przejazd:
 * zdarzenia (typ W: wypadki, awarie, zablokowania) oraz zamknięcia drogi. Długotrwałe roboty (typ U) pomijamy, by nie zalewać listy.
 */
export function parseGddkia(xml, nowMs, regionIds) {
  const p = new XMLParser({ ignoreAttributes: false, attributeNamePrefix: "@_", processEntities: true, trimValues: true });
  let j; try { j = p.parse(String(xml)); } catch { return []; }
  const arr = (x) => (x == null ? [] : Array.isArray(x) ? x : [x]);
  const ids = new Set(regionIds), out = [];
  for (const u of arr(j?.utrudnienia?.utr)) {
    const region = RAW_FOLD(oneLine(u.woj));
    if (!ids.has(region)) continue;
    const closed = bool(u.droga_zamknieta), event = String(oneLine(u.typ)).trim().toUpperCase() === "W";
    if (!closed && !event) continue;
    const from = warsawToMs(oneLine(u.data_powstania)), to = oneLine(u.data_likwidacji) ? warsawToMs(oneLine(u.data_likwidacji)) : null;
    if (from == null || from > nowMs + 36e5) continue;
    if (to != null && to < nowMs) continue; // już zakończone
    const road = oneLine(u.nr_drogi), sect = oneLine(u.nazwa_odcinka), eff = oneLine(u.skutki), detour = oneLine(u.objazd);
    const what = closed ? "droga zamknięta" : eff || "utrudnienia w ruchu";
    const title = clip(`${road}${sect ? ` · ${sect}` : ""}: ${what.charAt(0).toLowerCase() + what.slice(1)}`.replace(/\s+/g, " "), LIMITS.titleChars);
    out.push({ title, url: GDDKIA_LINK, date: new Date(from).toISOString(), summary: clip(detour, LIMITS.summaryChars), region, until: to != null ? new Date(to).toISOString() : null, key: `${road}|${oneLine(u.km)}|${from}` });
  }
  return out;
}

// ---------- Doniesienia medialne (regionalne rozgłośnie publiczne): tylko tytuły poważnych zdarzeń, bez sportu i kultury ----------
const MEDIA_SAFETY = ["alarm", "bomb", "ewakuac", "zagroz", "ostrzez", "grozb", "pozar", "wybuch", "wypad", "zablokowan", "zamkniet", "utrudnien", "powodz", "podtopien", "wichur", "nawalnic",
  "burz", "tornado", "gololed", "skazeni", "katastrof", "nie zyje", "nie zyja", "zgin", "smiertel", "ranni", "ranny", "rannych", "strzelani", "nozown", "atak", "zamach", "dron", "rakiet", "syren",
  "sabotaz", "dywersj", "szpieg", "wojn", "bron jadrow", "bron biolog", "bron chemicz", "zestrzel", "przestrzen powietrzn", "mobilizac", "inwazj", "agresj", "cyberatak",
  "zabojstw", "morderstw", "napad", "porwan", "zaginion", "brak pradu", "brak wody", "przerw w dostaw", "awari", "zatruc", "epidemi"];
const MEDIA_DENY = ["mecz", "liga", "ligi", "turniej", "puchar", "zawodnik", "zawodnicz", "pilkarz", "pilkark", "siatkar", "koszykar", "reprezentacj", "wyscig", "koncert", "festiwal", "wystaw", "premiera", "premiery",
  "kino", "teatr", "spektakl", "konkurs", "rocznic", "jubileusz", "horoskop", "rozmowa", "reportaz", "podcast", "felieton", "wideo", "quiz", "gosc", "wywiad", "ekspert", "pogoda na", "targi", "zwyciez", "pokonal", "przegral",
  // polityka i „burze” w przenośni, sądy, imprezy, remonty: nie dotyczą bezpieczeństwa
  "wybor", "koalicj", "prawic", "lewic", "opozycj", "sondaz", "sejm", "posel", "poslank", "burza po", "burza wokol", "burza medialn", "burza polityczn", "burza w sieci", "burza w internecie",
  "wyrok", "skazan", "biegl", "sad podja", "zajal sie sad", "forum", "rywaliz", "zawody", "remont"];
/** Filtr mediów: tytuł musi zawierać słowo o zagrożeniu/poważnym zdarzeniu i nie zawierać słów ze sportu, kultury i rozmów. */
// Słowa „miękkie” (forma materiału: wideo, wywiad…) nie kasują poważnego zdarzenia. „Twarde” (sport, kultura, polityka, sądy) odrzucają zawsze:
// „Zabił bramkę” to mecz, a „skazany za zabójstwo” to wyrok, nie bieżące wydarzenie.
const SOFT_DENY = ["wideo", "gosc", "ekspert", "rozmowa", "wywiad", "reportaz", "podcast", "felieton"];
const HARD_DENY = [...MEDIA_DENY.filter((w) => !SOFT_DENY.includes(w)), "bramk", "proces", "akt oskarz", "apelac", "sedzi"];
export function passesMedia(title) {
  const strong = strongIncident(title);
  if (!matches(title, MEDIA_SAFETY) && !strong) return false;
  if (!matches(title, MEDIA_DENY)) return true;
  return nationalThreat(title) || (strong && !matches(title, HARD_DENY)); // „zamach na premiera” nie jest premierą teatralną
}

/** Minimalny czytnik robots.txt: czy User-agent „*” (lub nasz) może pobrać ścieżkę. Brak pliku = wolno. */
export function robotsAllows(txt, path, ua = "egida") {
  const groups = []; let cur = null, lastWasUa = false;
  for (const raw of String(txt || "").split(/\r?\n/)) {
    const line = raw.replace(/#.*/, "").trim(); if (!line) continue;
    const i = line.indexOf(":"); if (i < 0) continue;
    const k = line.slice(0, i).trim().toLowerCase(), v = line.slice(i + 1).trim();
    if (k === "user-agent") { if (!lastWasUa) { cur = { agents: [], rules: [] }; groups.push(cur); } cur.agents.push(v.toLowerCase()); lastWasUa = true; continue; }
    lastWasUa = false;
    if (cur && (k === "allow" || k === "disallow")) cur.rules.push([k, v]);
  }
  const mine = groups.filter((g) => g.agents.some((a) => a !== "*" && ua.includes(a)));
  const use = mine.length ? mine : groups.filter((g) => g.agents.includes("*"));
  let best = null;
  for (const g of use) for (const [k, v] of g.rules) {
    if (!v) continue;
    const pat = v.replace(/[.+?^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*").replace(/\\\$$/, "$");
    if (new RegExp("^" + pat).test(path) && (!best || v.length >= best.len)) best = { len: v.length, allow: k === "allow" };
  }
  return best ? best.allow : true;
}

// ---------- Strona artykułu (warstwa ostatniej szansy dla miejsca) ----------
/** Co portal zazwyczaj wpisuje na stronie artykułu: opis, dział, słowa kluczowe, miejsce (JSON-LD), okruszki, początek treści. */
export function articleInfo(html) {
  const h = String(html || "").slice(0, 900000);
  const meta = (names) => { for (const n of names) { const m = new RegExp(`<meta[^>]+(?:property|name)\\s*=\\s*["']${n}["'][^>]*>`, "i").exec(h); if (m) { const c = /content\s*=\s*["']([^"']*)["']/i.exec(m[0]); if (c && c[1].trim()) return stripTags(c[1]); } } return ""; };
  const cats = [meta(["article:section"]), meta(["keywords", "news_keywords"]), meta(["article:tag"])];
  const ld = [];
  for (const m of h.matchAll(/<script[^>]+application\/ld\+json[^>]*>([\s\S]*?)<\/script>/gi)) {
    try { const walk = (o) => { if (!o || typeof o !== "object") return; if (Array.isArray(o)) return o.forEach(walk); for (const k of ["articleSection", "keywords"]) if (o[k]) ld.push(Array.isArray(o[k]) ? o[k].join(" ") : String(o[k])); for (const k of ["contentLocation", "locationCreated", "spatialCoverage"]) if (o[k]) ld.push(typeof o[k] === "string" ? o[k] : [o[k].name, o[k].address?.addressRegion, o[k].address?.addressLocality].filter(Boolean).join(" ")); Object.values(o).forEach(walk); }; walk(JSON.parse(m[1])); } catch { /* uszkodzony JSON-LD */ }
  }
  for (const m of h.matchAll(/<(?:nav|ol|ul|div)[^>]+class\s*=\s*["'][^"']*breadcrumb[^"']*["'][^>]*>([\s\S]*?)<\/(?:nav|ol|ul|div)>/gi)) cats.push(stripTags(m[1]));
  const body = h.replace(/<(script|style|nav|aside|footer|header|noscript|form)\b[\s\S]*?<\/\1>/gi, " ");
  const art = /<article\b[\s\S]*?<\/article>/i.exec(body)?.[0] || /<main\b[\s\S]*?<\/main>/i.exec(body)?.[0] || body;
  const paras = [...art.matchAll(/<p\b[^>]*>([\s\S]*?)<\/p>/gi)].map((m) => stripTags(m[1])).filter((x) => x.length >= 40 && !/^(czytaj|zobacz|przeczytaj|polecamy|sprawdź|sprawdz|więcej|wiecej|reklama)/i.test(x));
  const text = [meta(["og:description", "description", "twitter:description"]), ...paras.slice(0, 3)].filter(Boolean).join(" ").slice(0, 1400);
  return { text, cats: [...cats, ...ld].filter(Boolean).join(" ; ").slice(0, 600) };
}
/** Czy dla wpisu z portalu krajowego warto pobrać stronę artykułu? Tylko gdy cienkie warstwy nie wskazały miejsca, a temat jest istotny (zdarzenie w Polsce albo temat „świat”). */
export function needsArticle(raw, src) {
  if (!src.national || src.kind !== "media" || raw.page) return false;
  if (resolvePlace(raw).status !== "none") return false;
  if (!passesFilter(src.filter, raw.title, raw.summary)) return false;
  const t = raw.title;
  return nationalThreat(t) || topicHit(`${t} ${raw.summary || ""}`) || (strongIncident(t) && !foreignEvent(t) && !isWorldPath(raw.url));
}
