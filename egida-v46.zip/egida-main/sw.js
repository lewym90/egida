// Service worker: offline dla treści (powłoka aplikacji z cache), komunikaty zawsze najpierw z sieci.
const VERSION = "egida-v46";
const SHELL = [
  "./", "index.html", "manifest.webmanifest", "css/style.css",
  "js/app.js", "js/content.js", "js/config.js",
  "js/geo.js", "js/neptun.js", "js/neptun-feed.js", "js/shelters.js", "js/mapscreen.js",
  "js/sheltersscreen.js", "js/classify.js", "js/poland-border.js", "js/demo.js",
  "js/version.js", "js/regions.js", "js/regions-data.js", "js/personal.js", "js/screens2.js", "js/polish.js", "js/ua-shade.js", "js/ua-oblasts.js", "js/news.js", "js/similar.js", "js/offline.js", "js/medical.js", "js/aed-extra.js", "js/icons.js", "js/air.js",
  "js/vendor/leaflet/leaflet.js", "js/vendor/leaflet/leaflet.css",
  "icons/favicon.png", "icons/logo.png", "icons/icon-192.png", "icons/icon-512.png", "icons/apple-touch-icon.png",
  "fonts/manrope-latin-500-normal.woff2", "fonts/manrope-latin-700-normal.woff2", "fonts/manrope-latin-800-normal.woff2",
  "fonts/manrope-latin-ext-500-normal.woff2", "fonts/manrope-latin-ext-700-normal.woff2", "fonts/manrope-latin-ext-800-normal.woff2",
  "fonts/source-sans-3-latin-400-normal.woff2", "fonts/source-sans-3-latin-600-normal.woff2", "fonts/source-sans-3-latin-700-normal.woff2",
  "fonts/source-sans-3-latin-ext-400-normal.woff2", "fonts/source-sans-3-latin-ext-600-normal.woff2", "fonts/source-sans-3-latin-ext-700-normal.woff2",
];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(VERSION).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", (e) => {
  e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== VERSION).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener("message", (e) => { if (e.data === "version" && e.source) e.source.postMessage({ version: VERSION }); });
self.addEventListener("fetch", (e) => {
  const req = e.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (url.origin !== location.origin) return; // nie dotykamy zewnętrznych żądań
  // Pliki JSON z tego samego adresu: sieć najpierw (limit 10 s), w razie braku sieci albo błędu serwera ostatnia dobra kopia.
  // Do pamięci trafiają tylko poprawne odpowiedzi (kod 200), żeby błąd serwera nie nadpisał dobrej kopii.
  if (url.pathname.endsWith(".json")) {
    e.respondWith((async () => {
      try {
        const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 10000);
        const r = await fetch(req, { signal: ctl.signal }); clearTimeout(t);
        if (r.ok) { const cp = r.clone(); caches.open(VERSION).then((c) => c.put(req, cp)); return r; }
        return (await caches.match(req)) || r;
      } catch { return (await caches.match(req)) || Response.error(); }
    })());
    return;
  }
  // Kod i style aplikacji: sieć najpierw (krótki limit), żeby nowa wersja wchodziła od razu; bez sieci – kopia z cache.
  const code = req.mode === "navigate" || /\.(js|css|html|webmanifest)$/.test(url.pathname) || url.pathname.endsWith("/");
  if (code) {
    e.respondWith((async () => {
      try {
        const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 4000);
        const r = await fetch(req, { signal: ctl.signal, cache: "no-cache" }); clearTimeout(t);
        if (r.ok) { const cp = r.clone(); caches.open(VERSION).then((c) => c.put(req, cp)); return r; }
        return (await caches.match(req, { ignoreSearch: true })) || r;
      } catch { return (await caches.match(req, { ignoreSearch: true })) || (await caches.match("index.html")) || Response.error(); }
    })());
    return;
  }
  // Czcionki, ikony: cache najpierw, w tle odświeżanie.
  e.respondWith(caches.match(req, { ignoreSearch: true }).then((hit) => {
    const net = fetch(req).then((r) => { if (r.ok) { const cp = r.clone(); caches.open(VERSION).then((c) => c.put(req, cp)); } return r; }).catch(() => hit);
    return hit || net;
  }));
});
